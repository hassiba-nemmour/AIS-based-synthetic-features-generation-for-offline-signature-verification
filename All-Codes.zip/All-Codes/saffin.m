function seuilAffin=saffin(matriceApp,totalApp,dim)

%%
% cette fonction calcule le seuil d'affinit� pour les exemples de la base
% d'apprentissage
%% ENTREE:
 % matriceApp: matrice contenant les donn�es d'apprentissage
 % totalApp: nombre de donn�es apprentissage
 % dim: la dimension du vecteur caract�ristiques

%% SORTIE:
 % seuilAffin: seuill d'affinit�

    aa=0;
    for i=1:(totalApp-1);
        for j=(i+1):totalApp; 
            a=(matriceApp(:,i)-matriceApp(:,j)).^2; 
            aa=aa+sum(a);        
        end,     
    end, 
    seuilAffin=(aa/((totalApp*(totalApp-1))/2)); 
end