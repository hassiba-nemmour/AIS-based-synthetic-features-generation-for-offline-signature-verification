clear all
close all
clc

load Features_Generation Genuine Skilled

cell1_cedar=Genuine;
cell2_cedar=Skilled;

   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   REFERENCE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

   for z= 1:55                                      %  de 1 � 10 users
   
        cell1_cedar(z)  ;                           % r�cup�rer chaque cellule
        p= cell2mat(cell1_cedar(z));                % convertir chaque cellules en matrice
        kk=p(:,10);                               % s�l�ctionner les 10 premiers vrais signatures for each usser 
          

        matrica=[];
        matrice1_caram=[];
        matrice1_cara=[];

        for m = 2          
        if m~=z  
                cell1_cedar(m);
                pp=cell2mat(cell1_cedar(m));
                zz=pp(:,1);
                matrice1_cara=[matrice1_cara zz];

                else 
          if      m==z
                  cell1_cedar(m-1);
                  ll=cell2mat(cell1_cedar(m-1));
                  po=ll(:,1);

          matrice1_caram=[matrice1_caram po];

          end
          end
          end
          
          matrice1_caramp=[matrice1_cara matrice1_caram];

          R=[kk matrice1_caramp];
          cell3{z}=R;

   end

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   TEST %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

     for l= 1:55                              
   
        cell1_cedar(l);                                 
        pl= cell2mat(cell1_cedar(l));               
        kl=pl(:,[1:9 11:24]);            
        
        cell2_cedar(l);                                
        pz= cell2mat(cell2_cedar(l));               
        kp=pz(:,1:24); 
        
        T= [kl kp];
        
         cell4{l}=T;
     end

%==========================================================================

App=2;
vectApp= zeros(App,55);    %vecteur etiquette Apprentissage                                                                       
vectApp(1,:)=1;                                                                                  
vectApp(2,:)=-1;        % LA sortie d�sirer 

Test=47;
vectTest= zeros(Test,55);    %vecteur etiquette Test                                                                        
vectTest(1:23,:)=1;                                                                                  
vectTest(24:47,:)=-1;          % LA sortie d�sirer 


%--------------------------------- SVM  classification -------------------------------
%   x=1;
%   h=1;
%   ll=1;
%   mm=1; 
%   qq=1;
% 
%   
%   max1=[];
%   
%   
%    for t=1:55
%        t
%       for C=1:1:10
%         for sigma=1:1:20
%     
%             
% 
%          cell3(t);
%          REF= cell2mat( cell3(t));
%          
%          cell4(t);
%          TEST= cell2mat( cell4(t));
%          
%          cell5(t);
%          VAL= cell2mat( cell5(t));
% 
% 
% %==========================================================================
% %------- Apprentissage et classification par par svm biclasse --------------
% % %==========================================================================
% % rd = zeros(App,10);     
% % td = zeros(Test,10);
% % vd = zeros(val,10);   % utiliser pour le calculs des fausses acceptations et les faux rejets
% 
% 
%  R=REF.';
%  T=TEST.';
%  VA=VAL.';
% 
%    
%             
%  %option=svmsmoset('TolKKT',1.0000e-005,'MaxIter',90000,'Display','final','KKTViolationLevel',0,'KernelCacheLimit',50000);
%  svmstruct=svmtrain(R,vectApp(:,t),'Kernel_function','rbf', 'rbf_sigma',sigma,'method','smo','BoxConstraint',C);
%                
%    % Classification avec donn�e apprentissage et test:
%            [s_ref, f_ref(:,t)]= svmdecision(R,svmstruct);
%            [s_test, f_test(:,t)]= svmdecision(T,svmstruct);
%            [s_val, f_val(:,t)]= svmdecision(VA,svmstruct);
%            
%            
% 
%  %%%%%%%%%%%%%%%%%%%%%% TAUX D'ERREUR TEST %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
% 
%            TRC=0;
% for sig = 1: Test   
%   if (s_test(sig)/vectTest(sig,t)==1) 
%       TRC=TRC+1;
%   end
% end  
% 
%  %=TRC;
% 
% 
%  %%%%%%%%%%%%%%%%%%%%% TAUX D'ERREUR VALIDATION %%%%%%%%%%%%%%%%%%%%%%%%%          
%            
%            for i=1:val
%                if(f_val(i,t)>0)
%                    td(i)=1;
%                else
%                    td(i)=-1;
%                end
%            end
%           
%            
%            TRCV=0;
% for sig = 1: val    
%   if (td(sig)/vectVal(sig,t)==1)
%       TRCV=TRCV+1;
%   end
% end  
% 
% 
% 
% v0_writers(x)=t;
% v1_test(h)=((TRC/Test)*100);
% v2_val(qq)=((TRCV/val)*100);
% v3_C(ll)=C;
% v4_Sigma(mm)=sigma;
% 
% 
% x=x+1;
% h=h+1;
% ll=ll+1;
% mm=mm+1;
% qq=qq+1;
%       
% 
% 
%         end
%         
%       end
%  
%    end
%       
%    
% parametres=[v0_writers; v3_C; v4_Sigma; v1_test; v2_val];
% 
% 
% tout_final=[];
% 
% 
% test_final=[];
% test_final2=[];
% tout_final=[];
% 
% 
% for r=0:200:10800
%     
%  echantillon=parametres(4,1+r:200+r);
%  [M,Indices]=max(echantillon);
%  rr=parametres(:,(Indices+r));
%  test_final=[test_final rr];
%  
% 
% end
% 
% 
% taux_test=((sum(test_final(4,:)))/55)
% taux_val= ((sum(test_final(5,:)))/55);
% 
% C=test_final(2,:);
% save('C');
% 
% sigma=test_final(3,:);
% save('sigma');
% 
% C_sigma1=test_final(2:3,:);
% save('C_sigma');
% 



%==========================================================================
%------------Preparation des donnees apprentissage-------------------------
%==========================================================================
%--------------------------------- SVM  classification --------------------

CC=6.9;
sigmaa=10.4;
 
 
   for t=1:55
      
       
%     CC=C(t);
%     sigmaa=sigma(t);


         cell3(t);
         REF= cell2mat( cell3(t));
         
         cell4(t);
         TEST= cell2mat( cell4(t));

%==========================================================================
%------- Apprentissage et classification par par svm biclasse -------------
% %========================================================================
 R=REF.';
 T=TEST.';
         
 svmstruct=svmtrain(R,vectApp(:,t),'Kernel_function','rbf', 'rbf_sigma',sigmaa,'method','smo','BoxConstraint',CC);
               
           [s_ref, f_ref(:,t)]= svmdecision(R,svmstruct);
           [s_test, f_test(:,t)]= svmdecision(T,svmstruct);           
       

  FRR=0;
        FAR=0;
        for i=1:23
            if s_test(i)==-1
               FRR=FRR+1;
            end
        end
        for i=24:47
            if s_test(i)==1
               FAR=FAR+1;
            end
        end
        FRR1=(FRR/23)*100;
        FAR1=(FAR/24)*100;

tmbcApp(t)=FRR1;
tmbcTest(t)=FAR1;
AERJK(t)=(FRR1+FAR1)/2;
   end
   
   
taux_FRR1= sum(tmbcApp)/55
taux_FAR1=sum(tmbcTest)/55
AERZ=sum(AERJK)/55

