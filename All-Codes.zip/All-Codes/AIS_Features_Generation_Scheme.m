clear all
close all
clc

load Features_Generation Genuine 

%% Artificial Immune System for handwritten signature verification:

rand('state',0)
%% Settings:
nbClass = 1;                          % number of classes
totalApp = 1;                         % total: training data
dim = 80;                             % Dimension of the feature vector

%...................................... AIRS Parameters ..............:

toClone=150;                          % Cloning rate
toMut=0.2;                            % Mutation rate proba 0.3
toHypMut=5;                           % HyperMutation Rate
nbRes=200;                            % number of resources
thresholdStim= 0.97;

% Desired Output Matrix App
vectApp=zeros(totalApp,1);
vectApp(1,1)=1;


for iter=1:1:55
    
iter

clear Donn
Donn=[];

clear MC
clear ARB
clear classARB
clear indMC
nbMC=ones(1,nbClass);
nbARB=ones(1,nbClass);


MatApp=cell2mat(Genuine(iter));
MatApp=MatApp(:,10);

   %% ============================ TRAIN ==========================

   
ma=max(max(MatApp));
MatApp=(MatApp/ma);

%% Initialization:
% Calculation of the affinity threshold:

seuilAffin=saffin(MatApp,totalApp,dim); 

%% Initialization of ARB cells and memories: 1 cell for each class
% Initialization of ARBs:

nb=1; % nb represents the number of cells per class initialized (here 1)
h=1;
%     
    for i=1:nbClass  
        count=0;
        while(count<nb)            % To put one example per class in the ARB  
            j=randi(totalApp,1);
            if (vectApp(j)==i)     % if the desired output of the random data matches the current class
                indARB(h)=j;       % index arb corresponding to the index of the data taken at random
                ARB(:,h)=MatApp(:,j);
                classARB(h)=i;     % class arb corresponding to current class
                count=count+1;
                h=h+1;
            end 
        end
    end  

% Random initialization of Memory cells:
for i=1:nbClass
        count=0;
        h=1;
        while(count<nb)
            j=randi(totalApp,1);
            if (vectApp(j)==i)   % if the desired output of the random data matches the current class
                indMC(h,i)=j;    % index MC corresponding to the index of the datum taken at random from class i
                MC(:,h,i)=MatApp(:,j);
                count=count+1;
                h=h+1;
            end
        end 
    end  

 
% Generation of ARBs and identification of memory cells:
tic
    for n=1: totalApp   
       ag=MatApp(:,n);
       desir_ag=vectApp(n);
       %clear ARB
       clear classARB 
        for s=1:10
            
% Mc-match memory cell identification:

        [nl nc]=size(ARB);
        
         clear dis
         clear dst
        
         clear ARB
         clear classARB    
        %[Mc_match, stimu, ind]=maxstim(ag, MC, nbMC, nbClass, desir_ag, dim);
        
    Mc_match=ag;
    stimu=1;
    ind=n;
    
% Generation of ARBs by hypermutation:
[AB, class, indice]=arbgen(Mc_match, stimu,toHypMut,toClone, toMut, dim, desir_ag, nbClass);
    
        for i=1:indice
            ARB(:,(nc+i))=AB(:,i);
            classARB(nc+i)=class(i); 
        end    
        clear AB; clear class;
   
     
%% Resource competition and candidate memory cell development:     
        arret=0;         
        repetition=0;
        spred=0;
    
        while(arret<1)
            
            [class]=ressourcealloc(ARB, classARB, ag, desir_ag ,dim, toClone, nbRes);    
            AB=ARB;
        
            clear ARB;
            clear classARB;   
        
%....... delete ARBs that have no resources .........            
            u=1;    
            for i=1:length(class)
                if class(i) < 100 
                    ARB(:,u)=AB(:,i);
                    classARB(u)=class(i);
                    u=u+1;        
                end       
            end   
    
% stop test before production of offsprings            
            if(spred~=0)
                [avStim]=averagestim(ARB, classARB, ag, nbClass, dim);
                arret=0;
                i=desir_ag;   
                if(avStim(i)>=seuilStim)
                    arret=1;
                end   
                if (arret==1)
                    spred=1;
                else
                    spred =0;
                    repetition=1;
                end
            end
    
% Production of offsprings for each ARB:            
            if(spred==0)
                clear AB;
                clear class;    
                [AB, class]=abspring(ARB, classARB, ag, dim, toClone, desir_ag,toMut, nbClass);    
                clear ARB;
                clear classARB;
                ARB=AB;
                classARB=class;
                spred=1;
            end   
            
% stop test with average stimulation calculation:            
            if(repetition==0)
                [avStim]=averagestim(ARB, classARB, ag, nbClass, dim);   
                arret=0;
                i=desir_ag;      
                if(avStim(i)>=seuilStim)
                    arret=1;
                end
            end  
            avStim(i);
        end  

   distanc=[];   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
    if s==1
               
   [candid, clacandi, position]=cellselectt(ARB, classARB, ag, desir_ag, dim);
   Donn=[Donn candid];
      
    else
        

   ARB (:, ~ any (ARB, 1)) = [];


       [z1 D]=size(Donn);
       [za AR1]=size(ARB);
       
       for q=1:D  % Candidates  
           
           for qq=1:AR1  %   ARB  
                if qq <=AR1
        dista(qq)=distance(Donn(:,q),ARB(:,qq),dim); % I calculate the distances between them
        
        if dista(qq)==0 % if the distance is null I delete the ARBs
            ARB(:,qq)=[] ;
            AR1=AR1-1 ;
           
        end
           end
           end
       end 
      
 %������������������������������������������������������������������������������������������������������
 [candidd1, clacandit, position1]=cellselecttt(ARB, classARB, ag, desir_ag, dim);
        
%������������������������������������������������������������������������������������������������������
 Donn=[Donn candidd1];
       
        end
    end
    end
 cell_MC1{iter}=Donn;
 aj1(iter)=n*s;
 save AIS cell_MC1 
end