clear all
close all
clc


load Features_Generation Genuine Skilled
load classement_Features_Euc cellclasse1


 for z= 1:55
    Genuine(z);                           
    p= cell2mat(Genuine(z));              
    R=p(:,10);                            
    cell3{z}=R;

    MCC=cell2mat(cellclasse1(z));

    simil=[];

    for j = 1:10     

    for i= 1:1

       similarity(i) = Cosine_Similarity( R(:,i), MCC(:,j) );

    end
       simil  = [simil  similarity];

    end

    ma=1;

    for ta=1:1:10
       d1=simil(1:ta);
       moy1(ma)=mean(d1);
       moy2(ma)= round(mean(d1),4);
       ma=ma+1;
    end



      final= mean(moy2) + 0.7 *std(moy2);
      final1=round(final,4)

      res = ismember(final1,moy2);

      if res == 1 
          [s1 s2]=find(moy2==final1);
          s3=s2(1);
      else
          [s1 s2]=find(moy2>final1) 
          s0=length(s2)
          s3=s2(s0)
      end

      nombre_MC(z)=s3;
      cell_moy{z}=moy2;
      final2(z)=final1;


 end
 minimum=min(nombre_MC)
 maximum=max(nombre_MC)
 
 
save Criteria cell_moy final2 nombre_MC


