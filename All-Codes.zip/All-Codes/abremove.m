function [ABB, clabb]=abremove(matric, claas, fact)
% cette fonction permet de supprimer le ARB dont la position est d�sign�e
% par fact � partir de la matrice des ARB.
a=size(matric);
h=1;
i=fact; 

  for j=1:(i-1)
      if(claas(j)~=100)
      ABB(:,h)=matric(:,j);
      clabb(h)=claas(j);
      h=h+1;
      end
  end
    
  
  for j=(i+1):a(2)
      if(claas(j)~=100)
    ABB(:,h)=matric(:,j);
      clabb(h)=claas(j);
      h=h+1;
      end
  end
  
      
  
  
 