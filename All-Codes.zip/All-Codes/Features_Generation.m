clear all
close all
clc 

for   i=1:55 

vrais_5=[];
for   j=1:24  

id= int2str(i);
jd= int2str(j); 

nfichiers1 = imread(['D:\AIRS\CEDAR BASE\VRAI\','original','_',id,'_',jd '.png']);
con=[];
for f1=1:5
LDF11 = LDF1(nfichiers1, f1);      
con= [con LDF11];
end
vrais_5= [vrais_5; con];

end 
Genuine{i}=vrais_5';              

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Fausses=[];
for   j1=1:24  

id1= int2str(i);
jd1= int2str(j1); 

con1=[];
nfichiers2 = imread(['D:\AIRS\CEDAR BASE\FAUSSES\','forgeries','_',id1,'_',jd1 '.png']);
for f2=1:5
LDF22 =  LDF1(nfichiers2, f2 );      
con1=[con1 LDF22];
end
Fausses= [Fausses; con1];
end 
Skilled{i}=Fausses';
end


save Features_Generation Genuine Skilled

