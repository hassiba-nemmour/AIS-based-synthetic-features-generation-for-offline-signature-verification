clear all
close all
clc

load Features_Generation Genuine Skilled

cell1_cedar=Genuine;
cell2_cedar=Skilled;

   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%% TRAIN DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

for z= 1:55                                    

cell1_cedar(z)  ;                           
p= cell2mat(cell1_cedar(z));               
kk=p(:,10);                              

matrice1_cara=[];
matrice1_caram=[];

for m = 2      
if m~=z  
cell1_cedar(m);
pp=cell2mat(cell1_cedar(m));
zz=pp(:,1);
matrice1_cara=[matrice1_cara zz];


else 
if      m==z
  cell1_cedar(m-1);
  ll=cell2mat(cell1_cedar(m-1));
  po=ll(:,1);

matrice1_caram=[matrice1_caram po];

end
end
end

matrice1_caramp=[matrice1_cara matrice1_caram];

R=[kk matrice1_caramp];
cell3{z}=R;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  TEST DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

for l= 1:55                              

cell1_cedar(l);                               
pl= cell2mat(cell1_cedar(l));                
kl=pl(:,[1:9 11:24]);            

cell2_cedar(l);                                 
pz= cell2mat(cell2_cedar(l));                
kp=pz(:,1:24); 
T= [kl kp];

cell4{l}=T;
end

%==========================================================================

App=2;
vectApp= zeros(App,55);                                                                           
vectApp(1,:)=1;                                                                                  
vectApp(2,:)=-1;        

Test=47;
vectTest= zeros(Test,55);                                                                           
vectTest(1:23,:)=1;                                                                                  
vectTest(24:47,:)=-1;          
%--------------------------------------------------------------------------
x=1;
h=1;
ll=1;
mm=1; 
qq=1;

for t=1:55
for C=1:1:10
for sigma=1:1:20

cell3(t);
REF= cell2mat( cell3(t));

cell4(t);
TEST= cell2mat( cell4(t));

%==========================================================================

 R=REF.';
 T=TEST.';
   
svmstruct=svmtrain(R,vectApp(:,t),'Kernel_function','rbf', 'rbf_sigma',sigma,'method','smo','BoxConstraint',C);             
[s_ref, f_ref(:,t)]= svmdecision(R,svmstruct);
[s_test, f_test(:,t)]= svmdecision(T,svmstruct);     

 %%%%%%%%%%%%%%%%%%%%%%  TEST ERROR RATE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          

           TRC=0;
for sig = 1: Test   
  if (s_test(sig)/vectTest(sig,t)==1) 
      TRC=TRC+1;
  end
end  

v0_writers(x)=t;
v1_test(h)=((TRC/Test)*100);
v3_C(ll)=C;
v4_Sigma(mm)=sigma;


x=x+1;
h=h+1;
ll=ll+1;
mm=mm+1;
qq=qq+1;
        end
        
      end
 
   end
   
parametres=[v0_writers; v3_C; v4_Sigma; v1_test];
test_final=[];
test_final2=[];
tout_final=[];


for r=0:200:10800
    
 echantillon=parametres(4,1+r:200+r);
 [M,Indices]=max(echantillon);
 rr=parametres(:,(Indices+r));
 test_final=[test_final rr];
 

end

C=test_final(2,:);
sigma=test_final(3,:);

%==========================================================================
     
for t=1:55
 
CC=C(t);
sigmaa=sigma(t);


     cell3(t);
     REF= cell2mat( cell3(t));

     cell4(t);
     TEST= cell2mat( cell4(t));

%==========================================================================
%------- Apprentissage et classification par par svm biclasse -------------
% %========================================================================
R=REF.';
T=TEST.';
svmstruct=svmtrain(R,vectApp(:,t),'Kernel_function','rbf', 'rbf_sigma',sigmaa,'method','smo','BoxConstraint',CC);

[s_test, f_test(:,t)]= svmdecision(T,svmstruct);
   

  FRR=0;
        FAR=0;
        for i=1:23
            if s_test(i)==-1
               FRR=FRR+1;
            end
        end
        for i=24:47
            if s_test(i)==1
               FAR=FAR+1;
            end
        end
        FRR1=(FRR/23)*100;
        FAR1=(FAR/24)*100;

tmbcApp(t)=FRR1;
tmbcTest(t)=FAR1;
AERJK(t)=(FRR1+FAR1)/2;
   end
   
   
taux_FRR1= sum(tmbcApp)/55
taux_FAR1=sum(tmbcTest)/55
AERZ=sum(AERJK)/55

