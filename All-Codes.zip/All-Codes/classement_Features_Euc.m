clear all
close all
clc


load Features_Generation Genuine Skilled
load AIS cell_MC1 

 for z= 1:55

     
    Genuine(z);                           
    p= cell2mat(Genuine(z));
    R=p(:,10);

    for i=1:80
    var=R(i,:);
    moy_var= mean(var);
    vect(i)= moy_var;
    vet_moy=vect'; 
    cell_vecteur{z}=vet_moy;
    end 
       
       
 end 

dim=80; 

for z= 1:55
    
    cell_vecteur(z);                              
    p= cell2mat(cell_vecteur(z));                  
    arab1=cell2mat(cell_MC1(z));
    [a b]=size(arab1);

    matrice=[];
    mat11=[];
  
    for j=1:10
    distance1(j)=distance(p(:),arab1(:,j), dim)
    end

    [na ba ]=sort(distance1)
    matrice=arab1(:,ba);
    mat11=[mat11 matrice];
    cellclasse1{z}=mat11;
    end

save classement_Features_Euc cellclasse1


 