function [AB, classe, indice]=arbgen(Mc_match,stim,toHypMut,toClone, toMut, dim, desir_ag, nbClass)

%% cette fonction gen�re des ARBs d'un antig�ne par hypermutation 

%% ENTREE
    % Mc_match: Mc_match
    % stimu: valeur de stimulation entre l'antig�ne et Mc-match
    % toHypMut: taux d'hyper mutation
    % toClone: taux de clonnage
    % toMut: taux de mutation
    % dim: dimension du vecteur caract�ristique
    % desir_ag: sortie desir� de l'antig�ne
    % nbClass: nombre de classes

%% SORTIE
    % AB: les ARBs gener�s
    % classe: classe de chacun des clones
    % indice: nombre de clones gener�
    
%% PROGRAMME
    nbClones=toHypMut*toClone*stim;
    nbClones=floor(nbClones);
    indice=1;
    i=1;
    MU(:,i)=Mc_match;
    classe(i)=desir_ag;  
    while i < nbClones  
        mcClone=Mc_match; 
        [mcClone, mutation, class]=mutate(mcClone, toMut, dim, desir_ag, nbClass); % ???
        if(mutation==1)
            MU(:,i+1)=mcClone;
            classe(i+1)=class;   
            indice=indice+1;
        end
        i=i+1;
    end
    AB=MU;
    
    
    
    
    
    
    
    
    