
function[claab]= ressourcealloc(ARB, classARB, ag, desir_ag ,dim, toClone, nbRes)

%% cette fonction permet de d�terminer les ressources et la survie de chaque
 % ARB
 
%% ENTREE
    % ARB : les ARB qu'on vient de g�nerer + ceux initialis� au d�but
    % classARB: classe de chacun des ARB qu'on � gener�
    % ag: antig�ne en entr� du syst�me
    % desir_ag: la classe de l'antig�ne en entr�e
    % dim: dimention du vecteur caract�ristique
    % toClone: taux de clonnage
    % nbRes: nombre de ressources autoris� dans le syst�me

%% SORTIE
    % claab

%% PROGRAMME
    minStim=0;
    maxStim=2;

    [nl2 nc2]=size(ARB);
    indice=1;
    for i=1: nc2
        if(classARB(i)==desir_ag)% on cherche les clones ARB qui sont de la m�me classe que l'antig�ne en entr�e
            reserve(indice)=i;
            stim=stimulation(ARB(:,i),ag, dim);
            if(stim < minStim)
                minStim=stim;
            end
            if(stim > maxStim)
                maxStim=stim;
            end     
            abStim(indice)=((stim-minStim)/(maxStim-minStim));% On calcule la stimulation de chacun des clones ARB
            %qui sont de la m�me classe que l'antig�ne en entr�e
             
            abRes(indice)=abStim(indice)*toClone; % On leur calcule aussi le nombre de ressources allou� � chacun d'eux    
            indice=indice+1;          
        end   
    end

    resAlloc=0;

    for i=1: (indice-1)
        resAlloc=resAlloc+abRes(i);% On calcule la somme des ressources
    end

    while (resAlloc >nbRes) % tant que la somme des ressources est superrieur aux nombre autoris�   
        diff=resAlloc-nbRes;
        mini=2;   % stimulation minimale que peut avoir un ARB
        for i=1:(indice-1)
            if((abStim(i)<mini)&&(reserve(i)~=0))
                mini=abStim(i); % On recherche le arb ayant la plus petite stimulation � l'antig�ne
                pos=reserve(i); % On r�cup�re sa position parmi l'ensemble des ARBs        
                fa=i;
            end                    
        end   
        if(abRes(fa)<=diff)% si le nb de ressources du arb ayant la plus petite stimulation 
            %est inferrieur ou �gal � la diff�rence ==> on supprime l'arb 
            
            resAlloc=resAlloc-abRes(fa);
            reserve(fa)=0; % on annule l'indice du arb parmis l'ensemble des ARBs ayant
            %la plus petite stimulation � l'antig�ne
            
            classARB(pos)=100; %????
           % f
        else % sinon, on ne le supprime pas ==> on lui diminue just le nombre de ressources
            abRes(fa)=abRes(fa)-diff;
            resAlloc=resAlloc-diff;       
        end    
    end
    claab=classARB;