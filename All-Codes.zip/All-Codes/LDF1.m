function LDF3 = LDF1( Image ,R )

% R=rayon (R=2 et P=voisinage=8)

[nl nc]=size(Image);

% Entourer l'image d'entr�e par des uns
    Image=[ones(R,nc+2*R)*255;ones(nl,R)*255 Image ones(nl,R)*255;ones(R,nc+2*R)*255];


LDF2=[]; 
    for i=(R+1):nl+R
       
        for j=(R+1):nc+R
            
            Z0=Image(i,j);
            Z1=Image(i-R,j-R);
            Z2=Image(i-R,j);
            Z3=Image(i-R,j+R);
            Z4=Image(i,j-R);
            Z5=Image(i,j+R);
            Z6=Image(i+R,j-R);
            Z7=Image(i+R,j);
            Z8=Image(i+R,j+R);
         
            
           Dh=Z4+Z5-2*Z0;
           Dv=Z2+Z7-2*Z0;
           Dc=Z3+Z6-2*Z0;
           Dd=Z1+Z8-2*Z0;
           
           if (Dh>0)
               Dhb=1;
           else Dhb=0;
           end
           
           if (Dv>0)
               Dvb=1;
           else Dvb=0;
           end
           
           if (Dc>0)
               Dcb=1;
           else Dcb=0;
           end
           
           if (Dd>0)
               Ddb=1;
           else Ddb=0;
           end
            
            LDF2_Concat=2^3*Dhb+2^2*Dvb+2^1*Dcb+2^0*Ddb;
            LDF2=[LDF2 LDF2_Concat]; 
            
        end
    end
    
    
LDF3=[];
for i=0:15

    ldff=0;
  for h= 1:length(LDF2) 
      
    if LDF2(h)== i
        ldff= ldff + 1;
    end 
  end
  LDF3= [LDF3  ldff];
end


%   Normalisation L2
  if sum(LDF3)~=0
    m=sum(LDF3(1,:).^2);
    m=sqrt(m);    
    LDF3=LDF3./m;
  end

end