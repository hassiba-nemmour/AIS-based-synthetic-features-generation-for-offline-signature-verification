function [ similarity ] = Cosine_Similarity ( vect1, vect2 )
% Cette fonction mesure la similarit� en cosinus entre deux vecteur �gaux
% Entr�e = vecteur 1 et vecteur 2
% Sortie = le taux de similarit� entre les deux vecteurs
s=0;
ss=0;
sss=0;
[nl,mc]=size(vect1);
for kk=1:(nl*mc)                                       % boucle pour parcourir tous le vecteur
    s=s+vect1(kk)*vect2(kk);                           % multiplication du vecteur descrip du mot par le vecteur descrip de chaque mot du 
end
for h=1:(nl*mc)                                   
ss=ss+(vect1(h)*vect1(h));                             % multiplication du vecteur descrip du mot par lui mm
end
ss=sqrt(ss);                                           % la racine carr� de la multiplication
for h=1:(nl*mc)
sss=sss+(vect2(h)*vect2(h));                           % multiplication du vecteur descrip de chaque mot extrait du document 
end
sss=sqrt(sss);                                         % la racine carr� de la multiplication                                     
similarity=(s/(ss*sss));                            % la d�vision
end