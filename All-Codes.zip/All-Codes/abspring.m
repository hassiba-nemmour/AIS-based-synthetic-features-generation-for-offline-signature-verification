function [ABB, clabb]=abspring(ARB, classARB, ag, dim, toClone,desir_ag, toMut,nbClass)

%% cette fonction permet de calculer des offspring pour chaque ARB 

%% ENTREE
    % ARB: les clones apr�s comp�titions des ressurces
    % classARB: la classe des ARBs apr�s comp�tition des ressources
    % ag: l'antig�ne en entr�e
    % dim: la dimension du vecteur caract�ristique
    % toClone: taux de clonnage
    % desir_ag: la classe de l'antig�ne en entr�e
    % toMut: taux de mutation
    % nbClass: le nombre de classes qu'un antig�ne peux avoir (2: vraie ou faux)

%% SORTIE
    % ABB: ARB apr�s production des offsprings
    % clabb: les nouvelles classes des new ARBs g�ner�

%% PROGRAMME

[nl3 nc3]=size(ARB);
h=1;
indii=0;
for i=1: nc3
    if(classARB(i)==desir_ag)
        change=randi(100)/100;
        stim=stimulation(ARB(:,i),ag, dim);
        claa=classARB(i);
        if(stim >change)
            numclones=stim*toClone;
            nn=floor(numclones);
            j=1;
            while (j <= nn)
                abclone=ARB(:,i);
                % On clone les ARBs qui sont apte � �tre mut� parmis les ARBs de la m�me classe que l'antig�ne en entr�e
                [abclone, mute, classe]=mutate(abclone, toMut, dim, claa, nbClass);          
                if(mute==1)
                    MU(:,h)=abclone; 
                    clase(h)=classe;
                    h=h+1;
                    indii=1;
                end
                j=j+1;
            end      
        end
    end
end

h=0;
% On enregistre les anciens ARBs dans ABB
for i=1:nc3
    ABB(:,i)=ARB(:,i);
    clabb(i)=classARB(i);
    h=h+1;
end

% On rajoute les ARBs mut� aux anciens ARBs dans ABB
if(indii==1)
    a=size(MU);
    for i=1:a(2)       %???
        ABB(:,i+h)=MU(:,i);
        clabb(i+h)=clase(i);
    end
end