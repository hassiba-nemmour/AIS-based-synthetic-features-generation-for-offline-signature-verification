function [stim]=stimulation(vec1,vec2, dim)
% Cette fonction calcule la stimulation entre un antig�ne et un ARB
% correspondant � mcmatch
%% ENTREE
    % vec1: antig�ne
    % vec2: Mc_match
    % dim: taille du vecteur caract�ristique

%% SORTIE
    % stim: stimulation entre un antig�ne et Mc_match

%% PROGRAMME
    a=(vec1(:)-vec2(:)).^2; 
    dst=sqrt(sum(a)/dim); 
    stim=1-dst;