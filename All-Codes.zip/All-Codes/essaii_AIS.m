clear all
close all
clc

load classement_moyenne cellclasse1
load Criteria cell_moy final2 nombre_MC
load Features_Generation Genuine Skilled

cell1=Genuine;
cell2=Skilled;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   REFERENCE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   


 tout_MC1=[];
 mat_final1=[];
 cell_mat_final1=[];
 
   for z= 1:1:55                                   %  de 1 � 10 users
   
  MC_number=nombre_MC(z);
       
        cell1(z);                                % r�cup�rer chaque cellule
        p= cell2mat(cell1(z));                   % convertir chaque cellules en matrice
        kk=p(:,10);                           % s�l�ctionner les 10 premiers vrais signatures for each usser 
         
        
        arabb=cell2mat(cellclasse1(z)); 
 
        cel_MC=arabb(:, [1:MC_number]);


        conca=[kk cel_MC];
        
        [a b]=size(conca);
        
        matrica=[];
        matrice1_caram=[];
        matrice1_cara=[];
           
 va=[];
 r=1;
 
 for m = 2:2:b*2          % indice des autres utilisateurs par rapport le 1
        if m~=z  
         
                cell1(m);
                pp=cell2mat(cell1(m));
                zz=pp(:,1);
                matrice1_cara=[matrice1_cara zz];
                
                r= r+1;  
          
                else 
          if      m==z
                  cell1(m-1);
                  ll=cell2mat(cell1(m-1));
                  po=ll(:,1);

                 matrice1_caram=[matrice1_caram po];
            
          end
          end
        end
          
          matrice1_caramp=[matrice1_cara matrice1_caram];

          R=[conca matrice1_caramp];
          cell3{z}=R;

    end

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   TEST %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

     for l= 1:55                             %  de 1 � 10 users
   
        cell1(l);                                 % r�cup�rer chaque cellule
        pl= cell2mat(cell1(l));                % convertir chaque cellule en matrice
        kl=pl(:,[1:9 11:24]);            % s�l�ctionner les 10 premiers vrais signatures for each ussers 

      % matrice3=[matrice3 kl];
        
         cell2(l);                                 % r�cup�rer chaque cellule
        pz= cell2mat(cell2(l));                % convertir chaque cellules en matrices
        kp=pz(:,1:24); 
        
      % matrice4=[matrice4 kp];
        T= [kl kp];
        
         cell4{l}=T;
     end

%==========================================================================
%------------Preparation des donnees apprentissage-------------------------
%==========================================================================

Test=47;
vectTest= zeros(Test,55);    %vecteur etiquette Test                                                                        
vectTest(1:23,:)=1;                                                                                  
vectTest(24:47,:)=-1;          % LA sortie d�sirer 

    %--------------------------------- SVM  classification -------------------------------
%   x=1;
%   h=1;
%   ll=1;
%   mm=1; 
%   qq=1;
%   app=1;

  
%   
%   
%    for t=1:55
%  clear   MCA   
%  clear vectApp
%  
%  clear f_ref
%  clear s_ref
%  
%  
% MCA=1+nombre_MC(t);
%    
% App=2*MCA;
% vectApp= zeros(App,1);          %vecteur etiquette Apprentissage                                                                       
% vectApp(1:MCA)=1;                                                                                  
% vectApp(MCA+1:2*MCA)=-1;        % LA sortie d�sirer 
% 
% 
%       for C=1:1:10
%         for sigma=1:1:20
%     
%             
% 
%          cell3(t);
%          REF= cell2mat( cell3(t));
%          
%          cell4(t);
%          TEST= cell2mat( cell4(t));
% 
% %==========================================================================
% %------- Apprentissage et classification par par svm biclasse --------------
% % %==========================================================================
% 
%  RR=REF.';
%  TT=TEST.';
%          
%  %option=svmsmoset('TolKKT',1.0000e-005,'MaxIter',90000,'Display','final','KKTViolationLevel',0,'KernelCacheLimit',50000);
%  svmstruct=svmtrain(RR,vectApp(:),'Kernel_function','rbf', 'rbf_sigma',sigma,'method','smo','BoxConstraint',C);
%                
%    % Classification avec donn�e apprentissage et test:
%          [s_ref, f_ref]= svmdecision(RR,svmstruct);
%          [s_test, f_test(:,t)]= svmdecision(TT,svmstruct);
%            
%                      
%  %%%%%%%%%%%%%%%%%%%%% TAUX D'ERREUR APP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
% 
%            TRCA=0;
% for si1g = 1: App   
%   if (s_ref(si1g)/vectApp(si1g)==1) 
%       TRCA=TRCA+1;
%   end
% end 
% 
% 
%  %%%%%%%%%%%%%%%%%%%%%% TAUX D'ERREUR TEST %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
% 
%            TRC=0;
% for sig = 1: Test   
%   if (s_test(sig)/vectTest(sig,t)==1) 
%       TRC=TRC+1;
%   end
% end  
% 
% 
% v0_writers(x)=t;
% v1_test(h)=((TRC/Test)*100);
% v2_All(app)=((TRCA/App)*100);
% 
% v3_C(ll)=C;
% v4_Sigma(mm)=sigma;
% 
% x=x+1;
% h=h+1;
% ll=ll+1;
% mm=mm+1;
% qq=qq+1;
% app=app+1;
%       
% 
%         end
%         
%       end
%  
%    end
%       
%    
% parametres=[v0_writers; v3_C; v4_Sigma; v1_test; v2_All];
% 
% 
% tout_final=[];
% 
% 
% test_final=[];
% test_final2=[];
% tout_final=[];
% 
% 
% for r=0:200:10800
%     
%  echantillon=parametres(4,1+r:200+r);
%  [M,Indices]=max(echantillon);
%  rr=parametres(:,(Indices+r));
%  
% %   if rr(5)  ~= 100
% %      while rr(5)  ~= 100
% %          echantillon(Indices)=0;
% %          [M,Indices]=max(echantillon);
% %          rr=parametres(:,(Indices+r));
% %      end
% %  end
%  test_final=[test_final rr];
%      
% end
% 
% taux_test=((sum(test_final(4,:)))/55);
% 
% C=test_final(2,:);
% sigma=test_final(3,:);
% C_sigma1=test_final(2:3,:);
    

%--------------------------------- SVM  classification --------------------
CC=6.9;
sigmaa=10.4; %10.4
 
   for t=1:55
      
 clear MCA1   
 clear vectApp1
 clear s_test
 clear f_test
 
MCA1=1+nombre_MC(t);
   
App1=2*MCA1;
vectApp1= zeros(App1,1);          %vecteur etiquette Apprentissage                                                                       
vectApp1(1:MCA1)=1;                                                                                  
vectApp1(MCA1+1:2*MCA1)=-1;        % LA sortie d�sirer 


%     CC=C(t);
%     sigmaa=sigma(t);


         cell3(t);
         REF1= cell2mat( cell3(t));
         
         cell4(t);
         TEST1= cell2mat( cell4(t));

%==========================================================================
%------- Apprentissage et classification par par svm biclasse -------------
% %========================================================================
 R1=REF1.';
 T1=TEST1.';
   
 svmstruct=svmtrain(R1,vectApp1(:),'Kernel_function','rbf', 'rbf_sigma',sigmaa,'method','smo','BoxConstraint',CC);
[s_test, f_test(:,t)]= svmdecision(T1,svmstruct);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  FRR=0;
        FAR=0;
        for i=1:23
            if s_test(i)==-1
               FRR=FRR+1;
            end
        end
        for i=24:47
            if s_test(i)==1
               FAR=FAR+1;
            end
        end
        FRR1=(FRR/23)*100;
        FAR1=(FAR/24)*100;

tmbcApp(t)=FRR1;
tmbcTest(t)=FAR1;
AERR(t)=(FRR1+FAR1)/2;

   end
   
 taux_FRR1= sum(tmbcApp)/55;
 taux_FAR1=sum(tmbcTest)/55;
 AER_final=sum(AERR)/55
   

 
 