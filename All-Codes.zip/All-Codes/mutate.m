function [clone, mutt, classe]=mutate(mcClone, toMut, dim, desir_ag, nbClass)

%% cette fonction effectue la routine de mutation pour g�n�rer de nouveaux ARBs
%% ENTREE
    % mcClone: Mc-match
    % toMut: taux de mutation
    % dim: dimension du vecteur caract�ristique
    % desir_ag: sortie desir� de l'antig�ne
    % nbClass: nombre de classes
%% SORTIE
    % clone: vecteur correspondant au clonne de Mc_match
    % mutt: vaut 1 ou z�ro informant si une mutation vient d'�tre faite ou pas
    % classe: classe correspondant au clonne generr�
    
%% PROGRAMME
    mutt=0;
    for i=1: dim
        change=randi(1000)/1000; % proba
        changeto=randi(1000)/1000;    
        if(change < toMut)
            mcClone(i)=changeto;
            mutt=1;
        end   
    end
    
% la classe de clone g�n�rer 
    if(mutt==1)
        change=randi(1000)/1000;  %Proba
        chanto=randi(nbClass);    %classe de clone g�n�rer 
        %if(change < toMut)
        %  classe=(chanto);     
            
        %else
            classe=desir_ag;      
        %end
        clone=mcClone;
        
 
    end
    if(mutt==0)
        clone=0;
        classe=100;             % ?????
    end   

