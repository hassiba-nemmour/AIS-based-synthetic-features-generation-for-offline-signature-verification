function [candid, clacandi, position]=cellselectt(ARB, classARB, ag, desir_ag, dim)
%% cette fonction permet la s�lection de la c�llule m�moire candidate qui
% est le ARB de la m�me classe que l'antig�ne pr�sentant la stimulation max
%% ENTREE
    % ARB: cellule ARB apr�s comp�tition des ressources et apr�s enrichissement
    % classARB: la classe des ARBs apr�s comp�tition des ressources et apr�s enrichissement
    % ag: l'antig�ne en entr�e
    % desir_ag: la classe de l'antig�ne en entr�e
    % dim: dimension du vecteur caract�ristique

%% SORTIE
    % candidate: cellule m�moire candidate
    % classCandi: la classe de la cellule m�moire candidate
t=[];

a=size(ARB);
h=1;
for i=1:a(2)% On parcour tout les ARBs qui restent ap�s comp�tition des ressources
    if(classARB(i)==desir_ag) % On parcoure les ARBs de la m�me classe que l'antig�ne en entr�e
        stimul(h)=stimulation(ARB(:,i),ag, dim);
        indice(h)=i;
        h=h+1;
   end
end
maxi=stimul(1);
position=indice(1);
for i=2:(h-1)
    if(stimul(i)>maxi)
        position=indice(i); % facteur contiendras l'indice dont la stimulation est maximum
    end
end
candid=ARB(:,position);
clacandi=classARB(position);
position=position ; 

t=[t position];

ARB(:,position)=[];
classARB([position])=[];


