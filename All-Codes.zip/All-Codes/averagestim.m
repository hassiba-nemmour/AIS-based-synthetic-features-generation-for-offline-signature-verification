function [avi]=averagestim(ARB, classARB, ag,nbClass, dim)
%% cette fonction permet de calculer la stimulation moyenne sur tous les ARB
%% ENTREE
    % ARB: les cellules ARBs apr�s comp�tition des ressources et enrichissement
    % classARB: la classe de chacun des ARBs g�ner�
    % ag: antig�ne en entr�e
    % nbClass: le nombre de classes (2 vraie ou faux)
    % dim: dimension du vecteur caract�ristique

%% SORTIE
    % avi: seuil de stimulation moyenne

a=size(ARB);

for i=1: nbClass
    avi(i)=0;
    indice=0;
    
   for j=1:a(2)
       if(classARB(j)==i)
            avi(i)=avi(i)+stimulation(ARB(:,j), ag, dim); 
            indice=indice+1;
       end
   end
   avi(i)=(avi(i)/indice);
end


    