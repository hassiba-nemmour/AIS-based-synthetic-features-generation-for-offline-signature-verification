 function [candidd1, clacandi, position]=cellselecttt(ARB, classARB, ag, desir_ag, dim)

t=[];

a=size(ARB);
h=1;
for i=1:a(2)% On parcour tout les ARBs qui restent ap�s comp�tition des ressources
   % if(classARB(i)==desir_ag) % On parcoure les ARBs de la m�me classe que l'antig�ne en entr�e
        stimul(h)=stimulation(ARB(:,i),ag, dim);
        indice(h)=i;
        h=h+1;
   %end
end
maxi=stimul(1);
position=indice(1);
for i=2:(h-1)
    if(stimul(i)>maxi)
        position=indice(i); % facteur contiendras l'indice dont la stimulation est maximum
    end
end
candidd1=ARB(:,position);
clacandi=classARB(position);
position=position ; 

t=[t position];

ARB(:,position)=[];
classARB([position])=[];