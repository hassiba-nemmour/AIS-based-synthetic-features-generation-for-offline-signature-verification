function [ histo ] = Gradient_HOT(imgOrig1)

%% This function calculates Gradient_HOT

%% Input: original image

%% Output: histo= histogram containing the k-b1s calculated on each image of the signature

%% Programme:
[Gmag,Gdir] = imgradient(imgOrig1); % Calcul des amplitudes de l'image gradient de chaque image 
image=Gmag;
[nl,nc]=size(image);
img=[ones(1,nc+2) ; ones(nl,1) image ones(nl,1) ; ones(1,nc+2)];
histo=[];


Template1=0;
Template2=0;
Template3=0;
Template4=0;
Template5=0;
Template6=0;
Template7=0;
Template8=0;
Template9=0;
Template10=0;
Template11=0;
Template12=0;
Template13=0;
Template14=0;
Template15=0;
Template16=0;
Template17=0;
Template18=0;
Template19=0;
Template20=0;

for i=1+1:nl+1
    for j=1+1:nc+1
        
        if (img(i,j)>img(i-1,j) && img(i,j)>img(i+1,j))      %  | Template 1 horizental
            Template1 = Template1 + 1;                   
        end
        
        if (img(i,j)>img(i,j+1) && img(i,j)>img(i,j-1))      %  | Template 2 vertical 
            Template2 = Template2 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j-1) && img(i,j)>img(i+1,j+1))%  | Template 3 diagonal de gauche a droite
            Template3 = Template3 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j+1) && img(i,j)>img(i+1,j-1))%  | Template 4 diagonal de droite a gauche 
            Template4 = Template4 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j) && img(i,j)>img(i,j-1))    %  | Template 5
            Template5 = Template5 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j) && img(i,j)>img(i,j+1))    %  | Template 6
            Template6 = Template6 + 1;                   
        end
        
        if (img(i,j)>img(i,j+1) && img(i,j)>img(i+1,j))    %  | Template 7
            Template7 = Template7 + 1;                   
        end
        
        if (img(i,j)>img(i,j-1) && img(i,j)>img(i+1,j))    %  | Template 8
            Template8 = Template8 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j-1) && img(i,j)>img(i-1,j+1))%  | Template 9
            Template9 = Template9 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j+1) && img(i,j)>img(i+1,j+1))%  | Template 10
            Template10 = Template10 + 1;                   
        end
        
        if (img(i,j)>img(i+1,j-1) && img(i,j)>img(i+1,j+1))%  | Template 11
            Template11 = Template11 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j-1) && img(i,j)>img(i+1,j-1))%  | Template 12
            Template12 = Template12 + 1;                   
        end
        
        
        if (img(i,j)>img(i-1,j-1) && img(i,j)>img(i+1,j))  %  | Template 13
            Template13 = Template13 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j+1) && img(i,j)>img(i+1,j))  %  | Template 14
            Template14 = Template14 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j) && img(i,j)>img(i+1,j-1))  %  | Template 15
            Template15 = Template15 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j) && img(i,j)>img(i+1,j+1))  %  | Template 16
            Template16 = Template16 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j+1) && img(i,j)>img(i,j-1))  %  | Template 17
            Template17 = Template17 + 1;                   
        end
        
        if (img(i,j)>img(i,j-1) && img(i,j)>img(i+1,j+1))  %  | Template 18
            Template18 = Template18 + 1;                   
        end
        
        if (img(i,j)>img(i-1,j-1) && img(i,j)>img(i,j+1))  %  | Template 19
            Template19 = Template19 + 1;                   
        end
        
        if (img(i,j)>img(i,j+1) && img(i,j)>img(i+1,j-1))  %  | Template 20
            Template20 = Template20 + 1;                   
        end

    end
end
hist=[Template1 Template2 Template3 Template4 Template5 Template6 Template7 Template8 Template9 Template10 Template11 Template12 Template13 Template14 Template15 Template16 Template17 Template18 Template19 Template20];
histo=[histo hist];

  % Normalisation L2
  if sum(histo)~=0
    m=sum(histo(1,:).^2);
    m=sqrt(m);    
    histo=histo./m;
  end

end

